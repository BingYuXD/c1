#include <stdio.h>
#include<stdlib.h>

void ex8()
{
	int arr[6] = { 10,89,45,65,21,84 };
	int i, j, temp, k,size,flag;

	size = sizeof(arr) / sizeof(int);

	printf("-------------��ƱƧǫe---------------\n");

	for (i = 0; i < size; i++)
		printf("%d ", arr[i]);

	printf("\n--------------------------------------\n");

	for (i = 0; i<size - 1; i++) {
		flag = 0;
		for (j = 0; j<size - i - 1; j++)
			if (arr[j] > arr[j + 1]) {
				flag = 1;  
				temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		printf("#%d pass: ", i + 1);
		for (k = 0; k<size; k++)
			printf("%d ", arr[k]);
		printf("\n");
		if (flag == 0) 
			break;
	}

	for (i = 1; i <= 25; i++)
		printf("-");
	printf("\n");
	printf(".....After sorted.......\n");
	for (i = 0; i<size; i++)
		printf("%d ", arr[i]);
	printf("\n");
}