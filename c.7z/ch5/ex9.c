#include <stdio.h>
#include<stdlib.h>

void ex9()
{
	int arr[6] = { 80,50,40,35,20,60 };
	int i, j, temp, k, size, flag,l,r,bingo,mid,in;

	size = sizeof(arr) / sizeof(int);

	printf("-------------��ƱƧǫe---------------\n");

	for (i = 0; i < size; i++)
		printf("%d ", arr[i]);

	printf("\n--------------------------------------\n");

	for (i = 0; i<size - 1; i++) {
		flag = 0;
		for (j = 0; j<size - i - 1; j++)
			if (arr[j] > arr[j + 1]) {
				flag = 1;
				temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		
		if (flag == 0)
			break;
	}
	for (i = 0; i<size; i++)
		printf("%d ", arr[i]);
	printf("\n");

	printf("�z�n�M�䨺�@�ӼƦr(��J�O�^��r���N����): ");
	while (scanf("%d",&in)==1)
	{
		l = 0;
		r = size - 1;
		bingo = 0;
		while (l<=r)
		{
			mid = (l + r) / 2;
			if (in ==arr[mid])
			{
				bingo = 1;
				break;
			}
			if (in < arr[mid])
				r = mid - 1;
			else
				l = mid + 1;
		}
	if(bingo==1)
		printf("�b arr[%d] ��� %d.\n", mid, in);
	else
		printf("�藍�_�A�d�L�����! \n");
	printf("�z�n�M�䨺�@�ӼƦr(��J�O�^��r���N����): ");
	}



}