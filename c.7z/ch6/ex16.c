#include<stdio.h>
#include<stdlib.h>

int f();

void ex16()
{
	int num;
	printf("Please input a number : ");
	scanf("%d", &num);
	printf("f(%d)=%d\n", num, f(num));

}

int f(int n)
{
	if (n > 1)
		return(n*f(n - 1));
	else
		return 1;
}