#include<stdio.h>
#include<stdlib.h>

void input();

void output3();
int arr[5];

void ex12()
{
	printf("���{���b���ե����ܼ�\n");
		input();
	output3();
}

void input()
{
	int index;
	for (index = 0; index < 5; index++)
	{
		printf("�п�J#%d ���", index + 1);
		scanf("%d", &arr[index]);
	}
}

void output3()
{
	int index;
	printf("\n");
	for (index = 0; index < 5; index++)
	{
		printf("arr[%d] is %d\n", index, arr[index]);
	}


}