#include<stdio.h>
#include<stdlib.h>

void printstar();

void ex8()
{
	int num;
	printf("�A�n�h�֬P�P:");
	scanf("%d", &num);
	printstar(num);





}
void printstar(n)
{
	int i;
	for (i = 1; i < n; i++)
		printf("��");
	printf("\n");


}