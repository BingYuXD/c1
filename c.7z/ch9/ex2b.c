#include<stdio.h>
#include<stdlib.h>

struct work
{
	char name[20];
	int hours;
	int pay;
	int total;
};
void calculate(struct work*);
void ex2b()
{
	struct work service;
	service.pay = 120;
	printf("�п�J�z���m�W:");
	scanf("%s", &service.name);
	printf("�п�J�u�@�ɼ�");
	scanf("%d", &service.hours);
	calculate(&service);
	printf("�z�`�@���~��O$%d\n", service.total);

	

	
}
void calculate(struct work *ptr)
{
	ptr->total = ptr->hours*ptr->pay;
}