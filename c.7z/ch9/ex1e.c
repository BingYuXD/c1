#include<stdio.h>
#include<stdlib.h>

void ex1e()
{
	struct order
	{
		char name[20];
		int sum;
	};
	struct order num1 = { "Kyogre",60 };

	printf("\n<<���Z��>>\n");

	printf("�ǥͩm�W: %s\n", num1.name);
	printf("���Z:%d\n", num1.sum);

}