#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
void insert();
void list1();
void del();

struct student
{
	int id;
	char name[10];
	double score;
	struct student *next;
};
struct student *head, *ptr;

void ex4c()
{
	int option;
	head = (struct student *)malloc(sizeof(struct student));
	do
	{
		printf("\n1 => �s�W�@�`�I\n");
		printf("2 => �R���@�`�I\n");
		printf("3 => �C�L��C���Ҧ��`�I\n");
		printf("4 => ����\n");
		printf("�п�ܤ@����: ");
		scanf("%d", &option);
		switch (option)
		{
		case 1 :
			insert();
			break;
		case 2 :
			del();
			break;
		case 3 :
			list1();
			break;
		case 4:
			printf("bye !!");
			break;

		default:
			break;
		}
	} while (option != 4);
	

}
void insert()
{
	ptr = (struct student *)malloc(sizeof(struct student));

	printf("\n<< Creating student data >>\n");

	printf("Student ID <int> : ");
	scanf("%d", &ptr->id);

	printf("Student name <string> : ");
	scanf("%s", &ptr->name);

	printf("Student score <double> : ");
	scanf("%lf", &ptr->score);

	/* �[���쵲��C���e�ݪ��B�J */
	ptr->next = head->next;
	head->next = ptr;

}
void list1()
{
	struct student *current;
	if (head->next == NULL)
		printf("The linked list is empty\n");
	else
	{
		current = head->next;
		printf("\n<< Listing student data >>\n");

		while (current!=NULL)
		{
			printf("%d %s %f\n", current->id, current->name, current->score);
			current = current -> next;
		}
	}
}
void del()
{
	struct student *current;
	current = head->next;

	if(current == NULL)
		printf("The linked list is empty !!!\n");
	else
	{
		head->next = current->next;
		printf("\n<< Delete a student data >>\n");
		printf("%-10d %-10s %-10.2f\n",
			current->id, current->name, current->score);
		free(current);
	}
}

