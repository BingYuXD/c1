#include<stdio.h>
#include<stdlib.h>


#define S 8
#define MAX  ( x > y) ? x : y
#define MIN  ( x < y) ? x : y
#define A  x-1
#define bb  {
void ex1()

bb	
	int x;
	scanf("%d ",&x);
	printf("%d ", A);



}
