// stdafx.cpp : 僅包含標準 Include 檔的原始程式檔
// $safeprojectname$.pch 會成為先行編譯標頭檔
// stdafx.obj 會包含先行編譯類型資訊

#include "stdafx.h"

// TODO:  在 STDAFX.H 中參考您需要的任何其他標頭，
// 而不要在這個檔案中參考
