#include<stdio.h>
#include<stdlib.h>

void ex2()
{
	int num1, num2, larger;
	printf("Please input two intergers:\n");
	printf("Please input first intergers:");scanf("%d",&num1);
	printf("Please input second intergers:"); scanf("%d", &num2);
	

	num1 > num2 ? (larger = num1) : (larger = num2);
	printf("%d greater value\n", larger);

}