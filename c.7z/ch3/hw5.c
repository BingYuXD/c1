#include<stdio.h>
#include<stdlib.h>

void hw5()
{
	int i = 1, sum = 0;

	while (sum<1000)
	{
		sum = sum + i;
		i++;
	}
	printf("n�̤p��:%d", i - 1);


}