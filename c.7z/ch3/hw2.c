#include<stdio.h>
#include<stdlib.h>

void hw2()
{
	int a, i, sum = 0;
	do
	{
		printf("��J�@�Ӱ���:");
		scanf("%d", &a);
	} while (a % 2>0);
	for (i = 2; i <= a; i = i + 2)
	{
		sum = sum + i;
	}

	printf("����:%d", sum);


}