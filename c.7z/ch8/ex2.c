#include<stdio.h>
#include<stdlib.h>

void ex2()
{
	int a = 100;
	int *p = &a;
	int **pp = &p;
	printf("a=%d  *p=%d  **pp=%d\n",a, *p, **pp);


}