#include<stdio.h>
#include<stdlib.h>

void ex7()
{
	char *str[13] = { "ab","cd","ef","gh","ij","kl","mn","op","qr","st","uv","wx","yz"};

	for (int x = 0; x < 13; x++)
	{
		for (int y = 0; y < 2; y++)
		{
			printf("%c ", *(*(str + x) + y));
			printf("%p  ", *(str + x) + y);
		}
		printf("\n");
	}
}