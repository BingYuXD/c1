#include<stdio.h>
#include<stdlib.h>

void ex3()
{
	int a = 3, b = 3;
	printf("a=%d", a);
	printf(",a++���Ǧ^��%d", a++);
	printf(",a=%d\n", a);
	printf("b=%d", b);
	printf(",++b���Ǧ^��%d", ++b);
	printf(",b=%d\n", b);


}