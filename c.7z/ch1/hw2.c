#include<stdio.h>
#include<stdlib.h> 
void hw2(void)
{
	char x1 = 'a', x2 = 'b', x3 = 'n';
	printf("%c%c%c%c%c%c", x2, x1, x3, x1, x3, x1);

	system("pause");
	return 0;

}