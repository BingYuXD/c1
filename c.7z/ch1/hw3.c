#include<stdio.h>
#include<stdlib.h> 
void hw3(void)
{
	int i, b = 0;

	for (i = 1; i<100; i = i + 2)
	{

		b = b + i;

	}
	printf("����:%d", b);
	system("pause");
	return 0;

}