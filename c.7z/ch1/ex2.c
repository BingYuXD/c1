#include<stdio.h>
#include<stdlib.h>

void ex2()
{
	int n;

	printf("Please input an integer:");
	scanf("%d", &n);
	printf("n=%d\n", n);

}