#include<stdio.h>
#include<stdlib.h>
void hw2(void)
{

	float a, sum;
	printf("�п�J�ū�: ");
	scanf("%f", &sum);
	a = 1.8*sum + 32;
	printf("%.2f", a);
	system("pause");
	return 0;
}