#include<stdio.h>
#include<stdlib.h>

void ex1()
{
	int num = 25;
	printf("\"%d%%���ǥͨӦۤp�d�a�x\"\n", num);


}
