#include<stdio.h>
#include<stdlib.h>

void ex2()
{
	printf("12%%4=%d\n", 12 % 4);
	printf("12%%5=%d\n", 12 % 5);
	printf("12%%16=%d\n", 12 % 16);
}