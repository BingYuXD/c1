#include<stdio.h>
#include<stdlib.h>
int number;

void output2();

void ex11()
{
	printf("Please enter a number");
	scanf("%d", &number);
	output2();



}

void output2()
{
	printf("Number is %d \n", number);

}