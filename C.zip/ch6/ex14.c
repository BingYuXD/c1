#include<stdio.h>
#include<stdlib.h>

void cube();

int num,sum;
void ex14()
{
	printf("�п�J�@�Ӿ��:");
	scanf("%d", &num);

	cube();

	printf("����:%d", sum);

}

void cube()
{
	

	sum = num*num*num;

}