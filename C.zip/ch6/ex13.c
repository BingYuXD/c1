#include<stdio.h>
#include<stdlib.h>

void output4();
int number = 100;

void ex13()
{
	printf("number is %d \n", number);
	output4();
}

void output4()
{
	int number = 200;
	printf("number is %d \n", number);

}