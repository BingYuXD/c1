#include <stdio.h>
#include<stdlib.h>
void output1();
void dash();
void ex2()
{
	printf("�I�s���\n");
	dash();
	printf("\n");
	output();
	dash();

	printf("\n�I�s����!\n");

	
}

void output1()
{
	int a = 0, b = 10;
	a += b;
	printf("\n���\!%d\n", a);
}

void dash()
{
	int i;
	for (i = 0; i < 50; i++) printf("-");


}