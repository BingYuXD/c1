#include<stdio.h>
#include<stdlib.h>

double a();

void ex6()
{	
	double ans;
	printf("�п�J�@�Ӽƭ�\n");

	ans = a();

	printf("�����:%.1f", ans);


}

double a()
{
	double in;
	scanf("%lf", &in);

	if (in >= 0)
		return(in);
	else
		return(in*-1);

}