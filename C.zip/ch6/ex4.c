#include<stdio.h>
#include<stdlib.h>

int calculate();
void ex4()
{
	printf("�m���D2\n");
	calculate();
}

int calculate()
{
	int in;
	printf("�п�J�@�Ӿ��:");
	scanf("%d", &in);

	if (in >= 60)
		printf("pass");
	else
		printf("down");
	

}