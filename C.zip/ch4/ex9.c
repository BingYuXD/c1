#include <stdio.h>
#include<stdlib.h>

void ex9()
{
	int num[2][3];
	int index1, index2,i;

	for (index1 = 0; index1 < 2; index1++)
	{
		for (index2 = 0; index2 < 3; index2++)
		{
			printf("�п�Jnum[%d][%d]�����:", index1, index2);
			scanf("%d",&num[index1][index2]);
		}
	}
	for (index1 = 0; index1 < 2; index1++)
	{
		for (index2 = 0; index2 < 3; index2++)
		{
			printf("%d ",num[index1][index2]);
			
		}
		printf("\n");
	}
	
	

}