#include<stdio.h>
#include<stdlib.h>

void ex2()
{
	int i, s[4];
	s[0] = 78;
	s[1] = 55;
	s[2] = 92;
	s[3] = 80;

	for (i = 0; i <= 3; i++)
		printf("s[%d]=%d\n", i, s[i]);



}