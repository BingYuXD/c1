#include<stdio.h>
#include<stdlib.h>

void ex6()
{
	int a[5] = { 7,48,30,17,62 };
	int i, max, min;
	min = max = a[0];

	for (i = 0; i < 5; i++)
	{
		if (a[i] > max)
			max = a[i];
		if (a[i] < min)
			min = a[i];
	}
	printf("�̤j��:%d", max);
	printf("�̤p��:%d", min);






}