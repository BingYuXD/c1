#include<stdio.h>
#include<stdlib.h>
void hw4(void)
{
	int i, a, b = 0;
	for (i = 1; i<11; i++)
	{
		a = i*i;
		b = b + a;


	}
	printf("����:%d", b);
	system("pause");
	return 0;
}