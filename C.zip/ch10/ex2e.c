#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<ctype.h>
char convert(char);


void ex2e()
{
	char ch;
	printf("�п�J�@�ӭ^��r��:");
	ch = _getche();
	if (isalpha(ch))
		printf("\nch=%c\n", convert(ch));
	else
		printf("\n�п�J�^��r��!\n");

}
char convert(char a)
{
	if (isupper(a))
		return a + 32;
	else if (islower(a))
		return a -32;
}
