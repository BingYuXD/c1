#include<stdio.h>
#include<stdlib.h>
#include"c.h"





void main()
{
	_Bool flog = 1;
	
	while (flog)
	{
		


		printf("1.�r����Jscanf()\n");
		printf("2.�B�zscanf()���I\n");
		printf("3.getch(),getche(),getchar(),putcjar\n");
		printf("4.getche()\n");
		printf("5.isalnum�d��\n");
		printf("6.isalpha() isdigit()�d��\n");
		printf("7.isupper() islower()�d��\n");
		printf("8.toupper() tolower()�d��\n");
		printf("9.���gtoupper() tolower() �m��\n");
		printf("------------------------\n");
		printf("�п�J�n����d��  ��0����  :");

		

		int input = 0;
		scanf("%d", &input);
		while (getchar() != '\n')
			;

		switch (input)
		{
		case 1:
			ex1a();
			break;
		case 2:
			ex1b();
			break;
		case 3:
			ex1c();
			break;
		case 4:
			ex1d();
			break;
		case 5:
			ex2a();
			break;
		case 6:
			ex2b();
			break;
		case 7:
			ex2c();
			break;
		case 8:
			ex2d();
			break;
		case 9:
			ex2e();
			break;

		default:
			break;
		}

		system("pause");
		system("cls");
	}

}