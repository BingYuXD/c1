#include<stdio.h>
#include<stdlib.h>

void ex2()
{
	int score[3][3] = { 74,72,63,60,90,95,94,84,86 };
	
	int index1, index2, total = 0;
	
	for (index1 = 0; index1 < 3; index1++)
	{
		printf("\n��%d �Ѫ����Ƥ��O��: ", index1 + 1);
		for (index2 = 0; index2 < 3; index2++)
		{
			printf("%3d", score[index1][index2]);
			total += score[index1][index2];
		}
		
	}
	printf("\n\n�`��: %d\n", total);
	printf("��������: %.2f\n", total / 9.0);



}