#include<stdio.h>
#include<stdlib.h>

void ex7()
{
	int i, j, n = 6;
	for (i = 1; i <= 6; i++)
	{	
		for (j = n; j >=i; j--)
		{
			printf(" ");
		}
		for (j = 1; j<=i; j++)
		{
			printf("*");
		}
		for (j = 1; j < i; j++)
		{
			printf("*");
		}

		printf("\n");
	}



}