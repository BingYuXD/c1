#include<stdio.h>
#include<stdlib.h>

void hw6()
{
	int i, j;

	for (i = 1; i <= 9; i++)
	{
		for (j = 1; j <= 9; j++)
		{
			printf("%2d*%2d=%2d ", i, j, i*j);
		}
		j = 1;
		printf("\n");
	}




}