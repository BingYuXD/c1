#include<stdio.h>
#include<stdlib.h>

void hw4()
{
	int i = 5, sum = 0, in;
	while (i <= 20)
	{
		in = i*i;
		printf("%d*%d=%d\n", i, i, in);
		sum = sum + in;
		i++;
	}


	printf("�`�M:%d", sum);


}