#include<stdio.h>
#include<stdlib.h>

void ex6()
{
	int i;

	char str[4][15] = { "Department","of","Information","Management" };
	
	
	for (i = 0; i < 4; i++)
	{
		printf("str+%d   =%p\n", i, str + i);
		printf("*(str+%d)=%p\n", i, *(str + i));
		printf("str[%d]  =%p\n", i, str[i]);
	}
	for (int x = 0; x < 4; x++)
	{
		for (int y = 0; y < 15; y++)
		{
			printf("%c", *(*(str + x) + y));
		}
		
	}


}