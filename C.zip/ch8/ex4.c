#include<stdio.h>
#include<stdlib.h>

void ex4()
{
	double d;
	double *p = &d;
	double **pp = &p;
	printf("�п�J�@double��:");
	scanf("%lf",&d);
	printf("a=%.2lf  *p=%.2lf  **pp=%.2lf\n", d, *p, **pp);
}