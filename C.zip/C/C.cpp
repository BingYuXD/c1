// C.cpp : 定義主控台應用程式的進入點。
//

#include "stdafx.h"


int main()
{
    return 0;
}

